[![Coverage](https://19-184024759-gh.circle-artifacts.com/0/tmp/artifacts/coverage.svg)](https://19-184024759-gh.circle-artifacts.com/0/tmp/artifacts/coverage.svg)
[ ![License: MIT](https://img.shields.io/badge/License-MIT-brightgreen.svg)](https://github.com/TUDelft-CITG/Route_optimization_in_dynamic_currents/blob/master/LICENSE.txt)

Route optimization in dynamic flow fields
====================================

## Installation

Installation using *pip install halem* is not yet available. Running following three lines in your command prompt will allow you installing the package as well:

``` bash
# Download the package
git clone https://github.com/TUDelft-CITG/Route_optimization_in_dynamic_currents

# Go to the correct folder
cd Route_optimization_in_dynamic_currents

# Install package
pip install -e .
```
